import Header from './assets/components/Header/Header.jsx';
import CoreConcept from './assets/components/CoreConcept/CoreConcept.jsx';
import { CORE_CONCEPTS, EXAMPLES } from './assets/data.js';
import TabButton from './assets/components/TabButton/TabButton.jsx';
import{ useState } from 'react';
function App() {
 
  let [selectedTopic, setSelectedTopic] = useState();
  function handleSelect(selectedButton){
    console.log('Selected Button', selectedButton);
    // tabContent= selectedButton;
    setSelectedTopic(selectedButton);
  }
  return (
    <div>
      <Header />
      <main>
        <section id="core-concepts">
          <h2>Time to get started!</h2>
          <ul>
            <CoreConcept {...CORE_CONCEPTS[0]}/>
            <CoreConcept {...CORE_CONCEPTS[1]}/>
            <CoreConcept {...CORE_CONCEPTS[2]}/>
            <CoreConcept {...CORE_CONCEPTS[3]}/>
          </ul>
        </section>
        <section id="examples">
          <h2>Examples</h2>
          <menu>
            <TabButton isSlected ={selectedTopic ==='components'} onSelect={()=>{handleSelect('components')}}> components </TabButton>
            <TabButton isSlected ={selectedTopic ==='jsx'} onSelect={()=>{handleSelect('jsx')}}> JSX </TabButton>
            <TabButton isSlected ={selectedTopic ==='props'} onSelect={()=>{handleSelect('props')}}> Props </TabButton>
            <TabButton isSlected ={selectedTopic ==='state'} onSelect={()=>{handleSelect('state')}}> State </TabButton>
          </menu>
          {!selectedTopic? <p> Please select a topic</p>:(
          <div id="tab-content">
	        <h3>Title</h3>
        	<p>Description</p>
	        <pre>
	        <code>
            {EXAMPLES[selectedTopic].code}
          </code>
	        </pre>
          </div>)}
          
        </section>
      </main>
    </div>

  );
}
export default App;