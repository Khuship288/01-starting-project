const reactDescriptions = ['Fundamental', 
  'Crucial', 'Core'];
import reactImg from 
'../../react-core-concepts.png';
import './Header.css';
function getRandomInt(max){
  return Math.floor(Math.random()*(max+1));
}

function Header(){
  const description = reactDescriptions[getRandomInt(2)];
  return(
    <header>
      <img src={reactImg} alt="Stylized atom" />
      <h1>React Essentials</h1>
      <p>
        {description} React concepts you will need for almost any app you are
        going to build!
      </p>
    </header>
  )
}
export default Header;